import React, { useState, useEffect } from 'react';

function App() {
  // Анимация топора
  const [axePosition, setAxePosition] = useState(100);
  const [crackVisible, setCrackVisible] = useState(false);

  useEffect(() => {
    // Запускаем анимацию при загрузке
    const interval = setInterval(() => {
      setAxePosition(prev => prev === 100 ? 150 : 100);
      setCrackVisible(true);
      setTimeout(() => setCrackVisible(false), 300);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // Стили контейнера
  const containerStyle = {
    backgroundColor: '#8B4513', // Деревянный фон
    width: '100vw',
    height: '100vh',
    margin: 0,
    padding: 0,
    position: 'relative',
    overflow: 'hidden'
  };

  // Стили асфальта
  const asphaltStyle = {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    height: '60%',
    backgroundColor: '#333',
    backgroundImage: 'linear-gradient(90deg, #444 1px, transparent 1px), linear-gradient(#444 1px, transparent 1px)',
    backgroundSize: '20px 20px',
  };

  // Стили трещины
  const crackStyle = {
    position: 'absolute',
    bottom: '60%',
    left: '50%',
    transform: 'translateX(-50%)',
    width: '200px',
    height: '10px',
    backgroundColor: '#666',
    borderRadius: '50%',
    opacity: crackVisible ? 1 : 0,
    transition: 'opacity 0.3s',
    boxShadow: '0 0 10px #999',
  };

  // Стили топора
  const axeStyle = {
    position: 'absolute',
    left: '50%',
    transform: `translateX(-50%) translateY(${axePosition}px)`,
    transition: 'transform 0.5s ease-in-out',
    width: '80px',
    height: '120px',
  };

  // Рукоять
  const handleStyle = {
    position: 'absolute',
    width: '20px',
    height: '80px',
    backgroundColor: '#5D4037',
    left: '30px',
    bottom: '0',
    borderRadius: '10px',
  };

  // Лезвие
  const bladeStyle = {
    position: 'absolute',
    width: '60px',
    height: '40px',
    backgroundColor: '#607D8B',
    clipPath: 'polygon(0% 100%, 50% 0%, 100% 100%)',
    left: '10px',
    top: '0',
  };

  return (
    <div style={containerStyle}>
      {/* Асфальт */}
      <div style={asphaltStyle}>
        <div style={crackStyle}></div>
      </div>

      {/* Топор */}
      <div style={axeStyle}>
        <div style={handleStyle}></div>
        <div style={bladeStyle}></div>
      </div>
    </div>
  );
}

export default App;